﻿#include <iostream>
#include <cmath>
using namespace std;

// Структура для хранения координат точки
struct Point {
    int x;
    int y;
};

// Функция для вычисления площади треугольника по координатам его вершин
double calculateTriangleArea(const Point& p1, const Point& p2, const Point& p3) {
    double area = std::abs((p1.x * (p2.y - p3.y) + p2.x * (p3.y - p1.y) + p3.x * (p1.y - p2.y)) / 2.0);
    return area;
}

int main() {
    setlocale(LC_ALL, "Russian");
    // Создаем массив точек треугольника
    Point triangle[3];

    // Задаем координаты вершин треугольника
    triangle[0].x = 1;
    triangle[0].y = 22;

    triangle[1].x = 37;
    triangle[1].y = 41;

    triangle[2].x = 55;
    triangle[2].y = 68;

    // Вычисляем площадь треугольника
    double area = calculateTriangleArea(triangle[0], triangle[1], triangle[2]);

    // Выводим площадь треугольника на экран
    cout << "Площадь треугольника: " << area << endl;
    if (area <= 0)
        cout << "Координаты не являются вершинами треугольника" << endl; 
    else
        cout << "Треугольник существует" << endl;

    return 0;
}
